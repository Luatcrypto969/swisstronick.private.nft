# swisstronick.private.nft
swisstronick TESTNET 2.0 Privete  NFT
